#FCC: Build a Personal Portfolio Webpage Exercise

This repository exists due to the fact that FreeCodeCamp.com's preferred online webpage host (codepen.io) only allows the use of custom assets, images in this case; as a "pro" (paid) feature. I hope to instead side-step this by hosting a copy of the webpage here, that contains the custom images; then simply link them into the codepen.io version.
